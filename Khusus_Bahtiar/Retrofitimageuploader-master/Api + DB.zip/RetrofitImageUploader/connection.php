<?php

$CON = mysqli_connect('localhost','root','','retrofitimageuploader') or die('connection failure');

?>
